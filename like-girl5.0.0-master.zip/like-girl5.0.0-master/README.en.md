# LikeGirl5.0.0

#### Description
New Ajax page infinite loading optimization pop-up style Use Pjax asynchronous request to process data For more information, go to 5.0.0 Document View&LikeGirl 5.0.0 Welcome Experience

#### Software Architecture
Software architecture description

## Preface

* *This project is free of charge and capable friends can carry out secondary development
* 
* *However, it is prohibited to sell in any way
* 
* *The original intention is to learn and communicate. If you can make your partner happy, it's also a good choice

### Project Statement



* *This project may be over. I don't have much time to maintain it
* 
* *The last version in 2022 is also the last version of the project. Today is the happy winter solstice holiday
* 
* *But here again, it must be emphasized that the project is completely free of charge, and reselling is prohibited in any way
* 
* *I don't care about what was sold before. Don't let me see it again
* 
* *The original intention of writing this is to study. I never thought about charging anything
* 
* *But here again, it must be emphasized that the project is completely free of charge, and reselling is prohibited in any way
* 
* *If someone has the cheek to sell open source projects for money, you can't afford to live. I can understand
* 
* *It is not easy to develop, but also requires a lot of energy and time. Please respect the copyright of the author
* 
* *The copyright information of the front page can be deleted (at the bottom of the front end)
* 
* *At present, the experience of unlimited loading pages written in Ajax will be more efficient. The music will not interrupt the playback. After debugging for two days, the basic problems encountered have been solved
* 
* *The backend uses Ajax asynchronous request to submit data in conjunction with the plug-in reminder pop-up
* 
* *Finally, it is emphasized that the project is completely free of charge. Please respect the copyright of the author. Thank you for your copyright awareness



## ##There's a long way to go in the Jianghu. See you later



### LikeGirl 5.0.0 update instructions



* *I suggest you don't disrespect others' achievements. It's shameful
* 
* *Newly added front-end full site pjax unlimited loading technology
* 
* *New front and rear Ajax data asynchronous request technology
* 
* *New front head image background Gaussian blur switch
* 
* *New front-end Ajax unlimited load switch
* 
* *Adding and modifying sensitive information requires entering a security code
* 
* *Add custom front-end global CSS style
* 
* *Add global content of customized front-end header (you can add css external links or other content)
* 
* *Add custom global content at the bottom of the front end (you can add js external links or other content)
* 
* *Optimize the problem of too long content/quantity display of back-end message pages
* 
* *Optimize back-end data coding to escape html characters
* 
* *Optimize preprocessed content of partial page database
* 
* *Optimize the animation effect of front-end page loading
* 
* *Optimization Reminder Pop up Window Use Open Source Plug ins
* 
* *Optimize the CSS style data acquisition judgment of front-end message board
* 
* *Repair the display of "??" in the database content virtual host/space Chinese content
* 
* *Fix the problem that the background management login page judges the special characters of the password
* 
* *Repair the website registration number, click it and you cannot jump to the official website of the Ministry of Industry and Information Technology
* 
* *Again, I just wrote this project as a trainer. I didn't think about earning a penny. I'm not allowed to sell it in any way. I'm responsible for all the consequences